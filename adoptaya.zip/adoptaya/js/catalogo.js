// ===== index.html: catálogo con filtros =====
function tarjeta(m){return `<div class="col-sm-6 col-lg-4 col-xl-3"><div class="card h-100 shadow-sm card-mascota"><img src="${m.img}" class="card-img-top" alt="Foto de ${m.nombre}"><div class="card-body d-flex flex-column"><h5 class="card-title">${m.nombre} <span class="badge bg-warning text-dark">${m.especie}</span></h5><p class="small text-muted mb-1"><i class="bi bi-calendar3"></i> ${edadTxt(m.edad)} · <i class="bi bi-rulers"></i> ${m.tam}</p><p class="card-text">${m.desc}</p><a href="detalle.html?id=${m.id}" class="btn btn-adopta mt-auto"><i class="bi bi-eye"></i> Ver Detalles</a></div></div></div>`;}

if($('lista')){
 [...new Set(MASCOTAS.map(m=>m.especie))].forEach(s=>$('fEspecie').add(new Option(s,s)));
 const filtrar=()=>{
  const q=$('buscar').value.trim().toLowerCase();
  const r=MASCOTAS.filter(m=>(!$('fEspecie').value||m.especie===$('fEspecie').value)&&(!$('fEdad').value||grupoEdad(m.edad)===$('fEdad').value)&&(!$('fTam').value||m.tam===$('fTam').value)&&m.nombre.toLowerCase().includes(q));
  $('lista').innerHTML=r.length?r.map(tarjeta).join(''):'<p class="text-center text-muted py-5">Ninguna mascota coincide. Prueba quitando algún filtro.</p>';
  $('conteo').textContent=`${r.length} de ${MASCOTAS.length} mascotas`;
 };
 ['buscar','fEspecie','fEdad','fTam'].forEach(id=>$(id).addEventListener('input',filtrar));
 $('limpiar').addEventListener('click',()=>{['buscar','fEspecie','fEdad','fTam'].forEach(id=>$(id).value='');filtrar();});
 filtrar();
}

// ===== detalle.html: ficha de la mascota =====
if($('ficha')){
 const m=MASCOTAS.find(x=>x.id===Number(new URLSearchParams(location.search).get('id')));
 if(!m){$('ficha').innerHTML='<div class="alert alert-warning">No encontramos esa mascota. <a href="index.html">Volver al catálogo</a></div>';}
 else{
  document.title=m.nombre+' · AdoptaYA';
  const otras=MASCOTAS.filter(x=>x.id!==m.id).sort((a,b)=>(b.especie===m.especie)-(a.especie===m.especie)).slice(0,4);
  $('ficha').innerHTML=`<div class="row g-4"><div class="col-md-6"><img src="${m.img}" class="foto-grande shadow" alt="Foto de ${m.nombre}"></div><div class="col-md-6"><h1>${m.nombre} <span class="badge bg-warning text-dark fs-6">${m.especie}</span></h1><p class="text-muted"><i class="bi bi-calendar3"></i> ${edadTxt(m.edad)} · <i class="bi bi-rulers"></i> Tamaño ${m.tam.toLowerCase()}</p><p class="lead">${m.desc}</p><p>${m.nombre} fue revisado por nuestro equipo veterinario y espera una familia que le dé paciencia, cariño y rutina.</p><h5>Requisitos de adopción</h5><ul class="list-group mb-3">${['Ser mayor de edad con identificación oficial',...REQ[m.especie]].map(r=>`<li class="list-group-item"><i class="bi bi-check-circle-fill text-success"></i> ${r}</li>`).join('')}</ul><a href="postulacion.html?id=${m.id}" class="btn btn-adopta btn-lg"><i class="bi bi-heart-fill"></i> Postularse para Adopción</a> <a href="index.html" class="btn btn-outline-secondary btn-lg">Volver</a></div></div>
  <h4 class="mt-5">También te pueden interesar</h4>
  <div id="carrusel" class="carousel slide" data-bs-ride="carousel"><div class="carousel-inner">${otras.map((o,i)=>`<div class="carousel-item ${i?'':'active'}"><a href="detalle.html?id=${o.id}" class="text-decoration-none"><img src="${o.img}" class="d-block w-100 rounded" alt="${o.nombre}"><div class="carousel-caption"><span class="badge bg-dark">${o.nombre} · ${o.especie}</span></div></a></div>`).join('')}</div><button class="carousel-control-prev" data-bs-target="#carrusel" data-bs-slide="prev" aria-label="Anterior"><span class="carousel-control-prev-icon"></span></button><button class="carousel-control-next" data-bs-target="#carrusel" data-bs-slide="next" aria-label="Siguiente"><span class="carousel-control-next-icon"></span></button></div>`;
 }
}
