// ===== postulacion.html: formulario con validación y localStorage =====
function yaPostulado(correo,mascotaId){
 return obtener('postulaciones').some(p=>p.correo===correo&&p.mascotaId===mascotaId);
}
const f=$('formPostulacion');
if(f){
 MASCOTAS.forEach(m=>f.mascota.add(new Option(`${m.nombre} (${m.especie})`,m.id)));
 const pre=new URLSearchParams(location.search).get('id');
 if(pre)f.mascota.value=pre;
 f.addEventListener('submit',e=>{e.preventDefault();
  const nombre=f.nombre.value.trim(),correo=f.correo.value.trim().toLowerCase(),mid=Number(f.mascota.value);
  const exp=f.experiencia.value.trim(),ev=f.evidencia.value.trim();
  const ok=[marcar(f.nombre,nombre.length>=3),marcar(f.correo,emailValido(correo)),marcar(f.mascota,mid>0),
   marcar(f.experiencia,exp.length>=10),marcar(f.evidencia,!ev||/^https?:\/\/\S+\.\S+$/.test(ev))].every(Boolean);
  if(!ok)return;
  if(yaPostulado(correo,mid)){
   mostrarAlerta('danger','<i class="bi bi-exclamation-triangle-fill"></i> Ya existe una postulación con ese correo para esa mascota. Revisa su estado en <a href="postulaciones.html">Postulaciones</a>.');return;}
  const m=MASCOTAS.find(x=>x.id===mid);
  guardar('postulaciones',[...obtener('postulaciones'),{id:Date.now(),nombre,correo,mascotaId:mid,mascota:m.nombre,especie:m.especie,experiencia:exp,evidencia:ev,estado:'En revisión'}]);
  f.reset();limpiarMarcas(f);
  mostrarAlerta('success',`<i class="bi bi-check-circle-fill"></i> ¡Postulación para ${m.nombre} registrada! Está <b>En revisión</b>. <a href="postulaciones.html" class="alert-link">Ver mis postulaciones</a>`);
 });
}
