// ===== postulaciones.html: tabla dinámica, estados, contadores y exportación =====
const ESTADOS=['En revisión','Aprobada','Rechazada'];
const BADGE={'En revisión':'warning text-dark','Aprobada':'success','Rechazada':'danger'};

function pintar(){
 const ps=obtener('postulaciones');
 $('tbody').innerHTML=ps.length?ps.map(p=>`<tr><td class="small">${p.id}</td><td>${esc(p.nombre)}<br><small class="text-muted">${esc(p.correo)}</small></td><td>${esc(p.mascota)} <small class="text-muted">(${p.especie})</small></td><td><span class="badge bg-${BADGE[p.estado]}">${p.estado}</span></td><td><div class="input-group input-group-sm"><select class="form-select" aria-label="Cambiar estado" onchange="cambiarEstado(${p.id},this.value)">${ESTADOS.map(e=>`<option ${e===p.estado?'selected':''}>${e}</option>`).join('')}</select><button class="btn btn-outline-danger" title="Eliminar" onclick="eliminar(${p.id})"><i class="bi bi-trash"></i></button></div></td></tr>`).join(''):'<tr><td colspan="5" class="text-center text-muted py-4">Aún no hay postulaciones. <a href="index.html">Elige una mascota</a> para empezar.</td></tr>';
 $('contadores').innerHTML=[...new Set(MASCOTAS.map(m=>m.especie))].map(s=>`<div class="col-6 col-md"><div class="card text-center shadow-sm"><div class="card-body py-2"><div class="fs-2 fw-bold text-success">${ps.filter(p=>p.especie===s&&p.estado==='Aprobada').length}</div><div class="small text-muted">${s}</div></div></div></div>`).join('');
}
function cambiarEstado(id,estado){
 guardar('postulaciones',obtener('postulaciones').map(p=>p.id===id?{...p,estado}:p));
 pintar();
}
function eliminar(id){
 if(!confirm('¿Eliminar esta postulación? Esta acción no se puede deshacer.'))return;
 guardar('postulaciones',obtener('postulaciones').filter(p=>p.id!==id));
 pintar();
}
function exportarPostulacionesTxt(){
 const postulaciones=obtener('postulaciones');
 if(!postulaciones.length){mostrarAlerta('warning','No hay postulaciones para exportar todavía.');return;}
 let contenido=`Listado de postulaciones - AdoptaYA\n`;
 contenido+=`Generado: ${new Date().toLocaleString('es-MX')}\n`;
 contenido+='='.repeat(40)+'\n\n';
 postulaciones.forEach(p=>{
  contenido+=`Adoptante: ${p.nombre}\n`;
  contenido+=`Mascota: ${p.mascota} (${p.especie})\n`;
  contenido+=`Estado: ${p.estado}\n`;
  contenido+='-'.repeat(40)+'\n';
 });
 const blob=new Blob([contenido],{type:'text/plain'});
 const url=URL.createObjectURL(blob);
 const enlace=document.createElement('a');
 enlace.href=url;enlace.download='postulaciones.txt';
 document.body.appendChild(enlace);enlace.click();document.body.removeChild(enlace);
 URL.revokeObjectURL(url);
}
if($('tbody')){pintar();$('btnExportar').addEventListener('click',exportarPostulacionesTxt);}
