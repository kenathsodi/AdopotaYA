// ===== Datos del catálogo (edad en meses) =====
const MASCOTAS=[
{id:1,nombre:"Rocky",especie:"Perro",edad:36,tam:"Grande",desc:"Labrador juguetón y leal, ideal para familias activas."},
{id:2,nombre:"Luna",especie:"Gato",edad:12,tam:"Pequeño",desc:"Gatita curiosa y cariñosa que ronronea todo el día."},
{id:3,nombre:"Max",especie:"Perro",edad:6,tam:"Mediano",desc:"Cachorro mestizo lleno de energía que ama correr."},
{id:4,nombre:"Mimi",especie:"Gato",edad:60,tam:"Pequeño",desc:"Gata tranquila y independiente, perfecta para departamento."},
{id:5,nombre:"Kiwi",especie:"Ave",edad:24,tam:"Pequeño",desc:"Periquito alegre que silba y se posa en tu hombro."},
{id:6,nombre:"Thor",especie:"Perro",edad:84,tam:"Grande",desc:"Pastor senior, noble y protector. Busca un hogar tranquilo."},
{id:7,nombre:"Nieve",especie:"Conejo",edad:18,tam:"Pequeño",desc:"Conejita blanca muy dócil que disfruta las zanahorias."},
{id:8,nombre:"Coco",especie:"Ave",edad:120,tam:"Mediano",desc:"Loro hablador y sociable; ya conoce varias palabras."},
{id:9,nombre:"Bruno",especie:"Perro",edad:8,tam:"Mediano",desc:"Cachorro cariñoso que aprende trucos con facilidad."},
{id:10,nombre:"Simba",especie:"Gato",edad:36,tam:"Mediano",desc:"Gato naranja sociable que se lleva bien con niños."},
{id:11,nombre:"Pelusa",especie:"Hámster",edad:10,tam:"Pequeño",desc:"Hámster sirio muy activo; adora su rueda nocturna."},
{id:12,nombre:"Canela",especie:"Perro",edad:24,tam:"Pequeño",desc:"Chihuahua dulce y atenta, ideal para compañía."}
].map(m=>({...m,img:`img/mascota${m.id}.jpg`}));

const REQ={
Perro:["Espacio para jugar y pasear a diario","Compromiso de paseos y visitas al veterinario","Esterilización y vacunas al día"],
Gato:["Hogar seguro con ventanas protegidas","Rascadores y arenero limpio","Esterilización y vacunas al día"],
Ave:["Jaula amplia y lejos de corrientes de aire","Tiempo diario para interactuar","Alimentación variada y revisión veterinaria"],
Conejo:["Corral o espacio libre de cables","Heno fresco y verduras diarias","Experiencia previa con animales pequeños"],
"Hámster":["Jaula amplia con rueda y refugio","Manejo cuidadoso y suave","Hogar tranquilo, sin ruidos fuertes de noche"]};

// ===== localStorage: todo se guarda como texto JSON =====
function obtener(clave){try{return JSON.parse(localStorage.getItem(clave))||[];}catch(e){return [];}}
function guardar(clave,datos){localStorage.setItem(clave,JSON.stringify(datos));}

// ===== Utilidades generales =====
const $=id=>document.getElementById(id);
function esc(t){const d=document.createElement('div');d.textContent=t;return d.innerHTML;}
function emailValido(c){return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(c);}
function edadTxt(m){return m<12?m+' meses':(m/12)+(m===12?' año':' años');}
function grupoEdad(m){return m<12?'cachorro':m<48?'joven':'adulto';}
function marcar(el,ok){el.classList.toggle('is-invalid',!ok);el.classList.toggle('is-valid',ok);return ok;}
function limpiarMarcas(f){f.querySelectorAll('.is-valid,.is-invalid').forEach(x=>x.classList.remove('is-valid','is-invalid'));}
function mostrarAlerta(tipo,msg){$('alertas').innerHTML=`<div class="alert alert-${tipo} alert-dismissible fade show" role="alert">${msg}<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button></div>`;}

function renderLayout(activo){
 const L=[['index.html','bi-grid','Catálogo'],['postulacion.html','bi-pencil-square','Postulación'],['postulaciones.html','bi-clipboard-check','Postulaciones'],['contacto.html','bi-envelope','Contacto']];
 $('nav').innerHTML=`<nav class="navbar navbar-expand-lg navbar-dark bg-adopta sticky-top"><div class="container"><a class="navbar-brand fs-4" href="index.html"><i class="bi bi-heart-fill text-warning"></i> AdoptaYA</a><button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#menu" aria-label="Menú"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="menu"><ul class="navbar-nav ms-auto">${L.map(l=>`<li class="nav-item"><a class="nav-link ${l[0]===activo?'active':''}" href="${l[0]}"><i class="bi ${l[1]}"></i> ${l[2]}</a></li>`).join('')}</ul></div></div></nav>`;
 $('pie').innerHTML='<div class="container text-center py-3">AdoptaYA · BUAP-FCC · Desarrollo de Aplicaciones Web · Otoño 2026</div>';
}

// ===== Contacto (contacto.html) =====
const fc=$('formContacto');
if(fc)fc.addEventListener('submit',e=>{e.preventDefault();
 const n=fc.nombre,c=fc.correo,m=fc.mensaje;
 const ok=[marcar(n,n.value.trim().length>=3),marcar(c,emailValido(c.value.trim())),marcar(m,m.value.trim().length>=10)].every(Boolean);
 if(!ok)return;
 guardar('mensajes',[...obtener('mensajes'),{id:Date.now(),nombre:n.value.trim(),correo:c.value.trim(),mensaje:m.value.trim()}]);
 fc.reset();limpiarMarcas(fc);
 mostrarAlerta('success','<i class="bi bi-check-circle-fill"></i> ¡Mensaje enviado! Te responderemos pronto.');
});
